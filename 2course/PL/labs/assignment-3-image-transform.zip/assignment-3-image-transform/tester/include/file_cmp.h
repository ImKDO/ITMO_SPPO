#include <stdio.h>

#include "cmp.h"

enum cmp_result file_cmp(FILE *f1, FILE *f2, size_t sz);
