#ifndef IMAGE_HEADER
#define IMAGE_HEADER


#include "bmp.h"
#include <stdint.h>

struct __attribute__((packed)) image {
  uint64_t width, height;
  struct pixel* data;
};
#endif
