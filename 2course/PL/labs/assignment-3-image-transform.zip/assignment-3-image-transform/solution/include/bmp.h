#ifndef BMP_HEADER
#define BMP_HEADER


#include  <stdint.h>
struct __attribute__((packed)) bmp_header
{
        uint16_t bfType;            // 0x4d42 | 0x4349 | 0x5450
        uint32_t  bfileSize;        // размер файла
        uint32_t bfReserved;        // 0
        uint32_t bOffBits;          // смещение до поля данных,
                                    // обычно 54 = 16 + biSize
        uint32_t biSize;            // размер струкуры в байтах:
                                    // 40(BITMAPINFOHEADER) или 108(BITMAPV4HEADER)
                                    // или 124(BITMAPV5HEADER)     
        uint32_t biWidth;           // 40(BITMAPINFOHEADER) или 108(BITMAPV4HEADER)
        uint32_t  biHeight;         // или 124(BITMAPV5HEADER)
        uint16_t  biPlanes;         // ширина в точках
        uint16_t biBitCount;        // 0 | 1 | 4 | 8 | 16 | 24 | 32
        uint32_t biCompression;     // BI_RGB | BI_RLE8 | BI_RLE4 |
                                    // BI_BITFIELDS | BI_JPEG | BI_PNG
                                    // реально используется лишь BI_RGB
        uint32_t biSizeImage;       // Количество байт в поле данных
                                    // Обычно устанавливается в 0     
        uint32_t biXPelsPerMeter;   // горизонтальное разрешение, точек на дюйм
        uint32_t biYPelsPerMeter;   // вертикальное разрешение, точек на дюйм
        uint32_t biClrUsed;         // Количество используемых цветов
                                    // (если есть таблица цветов)
        
        uint32_t  biClrImportant;   // Количество существенных цветов.
                                    // Можно считать, просто 0
};


struct __attribute__((packed)) pixel 
{ 
    uint8_t b, g, r;
};

#endif
