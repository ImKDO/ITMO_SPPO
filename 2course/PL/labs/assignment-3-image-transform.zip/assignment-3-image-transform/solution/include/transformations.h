#ifndef INTERFACE_TRANSFORMATIONS
#define INTERFACE_TRANSFORMATIONS
/* создаёт копию изображения, которая повёрнута на 90 градусов */
struct image rotate_none( struct image const source);
struct image rotate_cw90( struct image const source);
struct image rotate_ccw90( struct image const source);
struct image rotate_fliph( struct image const source);
struct image rotate_flipv( struct image const source);
#endif
