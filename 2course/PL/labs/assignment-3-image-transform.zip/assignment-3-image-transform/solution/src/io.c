#include <malloc.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "../include/bmp.h"
#include "../include/io.h"
#include "../include/image.h"

#define HEADER_TYPE 0x4D42
#define HEADER_RESERVED 0
#define HEADER_SIZE 40
#define HEADER_PLANES 1
#define HEADER_BIT_COUNT 24
#define HEADER_COMPRESSION 0

#define HEADER_PIXELS_PER_METER 2835
#define HEADER_COLORS_USED 0
#define HEADER_COLORS_IMPORTANT 0

void free_image(struct image *img)
{
    if (img->data) free(img->data);
    free(img);
}

static uint64_t get_padding_size(const struct image *img)
{
    return (4 - (img->width * sizeof(struct pixel) % 4)) % 4;
}

enum read_status from_bmp(FILE *input, struct image *img)
{

    if (!input)
    {
        return READ_INVALID_HEADER;
    }

    struct bmp_header bmp_header;

    if (fread(&bmp_header, sizeof(bmp_header), 1, input) != 1)
    {
        return READ_INVALID_HEADER;
    }

    if (bmp_header.bfType != HEADER_TYPE)
        return READ_INVALID_HEADER;
    if (bmp_header.biBitCount != HEADER_BIT_COUNT)
        return READ_INVALID_BITS;

    img->width = bmp_header.biWidth;
    img->height = bmp_header.biHeight;
    img->data = malloc(img->width * img->height * sizeof(struct pixel));

    if (!img->data)
    {
        return READ_INVALID_OUT_OF_MEMORY;
    }
    uint64_t padding = get_padding_size(img);
    for (uint64_t y = 0; y < bmp_header.biHeight; ++y)
    {
        if (fread(&img->data[y * img ->width], sizeof(struct pixel), img -> width, input) != img -> width)
        {
            free(img->data);
            return READ_INVALID_HEADER;
        }
        fseek(input, (long)padding, SEEK_CUR);
    }

    return READ_OK;
}

enum write_status to_bmp(FILE *out, struct image const *img)
{
    if (!out)
    {
        return WRITE_ERROR;
    }

    uint64_t padding_size = get_padding_size(img);
    uint64_t bmp_header_size = sizeof(struct bmp_header);
    uint64_t image_size = (img->width * sizeof(struct pixel) + padding_size) * img->height;
    struct bmp_header bmp_header = {
        .bfType = HEADER_TYPE,
        .bfileSize = bmp_header_size + image_size,
        .bfReserved = HEADER_RESERVED,
        .bOffBits = bmp_header_size,

        .biSize = HEADER_SIZE,
        .biWidth = img->width,
        .biHeight = img->height,
        .biPlanes = HEADER_PLANES,
        .biBitCount = HEADER_BIT_COUNT,
        .biCompression = HEADER_COMPRESSION,

        .biSizeImage = image_size,

        .biXPelsPerMeter = HEADER_PIXELS_PER_METER,
        .biYPelsPerMeter = HEADER_PIXELS_PER_METER,
        .biClrUsed = HEADER_COLORS_USED,
        .biClrImportant = HEADER_COLORS_IMPORTANT,
    };

    if (fwrite(&bmp_header, sizeof(bmp_header), 1, out) != 1)
    {
        return WRITE_ERROR;
    }

    // uint8_t padding[3] = {0};
    for (uint64_t y = 0; y < img->height; ++y)
    {
        uint64_t offset = y * img->width;
        if (fwrite(&img->data[offset], sizeof(struct pixel), img->width, out) != img->width)
        {
            return WRITE_ERROR;
        }
        uint8_t padding[3] = {0};
        fwrite(padding, 1, padding_size, out);
    }
    return WRITE_OK;
}
