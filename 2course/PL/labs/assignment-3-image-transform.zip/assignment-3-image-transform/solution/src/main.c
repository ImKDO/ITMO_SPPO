#include <malloc.h>
#include <stdio.h>
#include <string.h>

#include "../include/io.h"
#include "../include/bmp.h"
#include "../include/image.h"
#include "../include/transformations.h"

#define ARG_QUANTITY 4

enum parametrs { none, cw90, ccw90, flipv, fliph };

enum parametrs string_to_enum(const char *str) {
    if (strcmp(str, "none") == 0) return none;
    if (strcmp(str, "cw90") == 0) return cw90;
    if (strcmp(str, "ccw90") == 0) return ccw90;
    if (strcmp(str, "flipv") == 0) return flipv;
    if (strcmp(str, "fliph") == 0) return fliph;
    return -1;
}

int main(int argc, char **argv) {

    if (argc != ARG_QUANTITY) {
        fprintf(stderr, "Usage: %s <input_file> <output_file> <transformation>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "rb");
    if (!file) {
        fprintf(stderr, "Error: Cannot open input file\n");
        return 1;
    }

    struct image *img = malloc(sizeof(struct image));
    if (!img) {
        fprintf(stderr, "Error: No free memory for image\n");
        fclose(file);
        return 1;
    }

    enum read_status read_status = from_bmp(file, img);
    fclose(file);

    if (read_status != READ_OK) {
        fprintf(stderr, "Error: Cannot read BMP file (status: %d)\n", read_status);
        free(img);
        return 1;
    }

    struct image const img_input = {.width = img->width, .height = img->height, .data = (img->data)};
    struct image *img_output = malloc(sizeof(struct image));
    if (!img_output) {
        fprintf(stderr, "Error: No free memory for output image\n");
        free(img->data);
        free(img);
        return 1;
    }

    enum parametrs transformation_type = string_to_enum(argv[3]);
    if (transformation_type == -1) {
        fprintf(stderr, "Error: Unknown transformation\n");
        free(img->data);
        free(img);
        free(img_output);
        return 1;
    }

    switch (transformation_type) {
        case none:
            *img_output = rotate_none(img_input);
            break;
        case cw90:
            *img_output = rotate_cw90(img_input);
            break;
        case ccw90:
            *img_output = rotate_ccw90(img_input);
            break;
        case flipv:
            *img_output = rotate_flipv(img_input);
            break;
        case fliph:
            *img_output = rotate_fliph(img_input);
            break;
    }

    FILE *file_output = fopen(argv[2], "wb");
    if (!file_output) {
        fprintf(stderr, "Error: Cannot open output file\n");
        free(img_output->data);
        free(img_output);
        free(img->data);
        free(img);
        return 1;
    }

    enum write_status write_status = to_bmp(file_output, img_output);
    fclose(file_output);

    if (write_status != WRITE_OK) {
        fprintf(stderr, "Error: Cannot write BMP file (status: %d)\n", write_status);
        free(img_output->data);
        free(img_output);
        free(img->data);
        free(img);
        return 1;
    }

    // Clean up resources
    free(img_output->data);
    free(img_output);
    free(img->data);
    free(img);

    return 0;
}
