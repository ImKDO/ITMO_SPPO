#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>

#include "../include/image.h"
#include "../include/transformations.h"

struct image rotate_none(struct image const source) {
    // struct image image_transform;

    // image_transform.width = source.width;
    // image_transform.height = source.height;
    // image_transform.data = malloc(source.width * source.height * sizeof(struct pixel));

    // if (!image_transform.data) {
    //     perror("Error: not enough memory for rotate_none");
    //     exit(1);
    // }

    // for (uint64_t i = 0; i < source.width * source.height; ++i) {
    //     image_transform.data[i] = source.data[i];
    // }

    return source;
}

struct image rotate_ccw90(struct image const source) {
    struct image image_transform;

    uint64_t width = image_transform.width = source.height;
    uint64_t height = image_transform.height = source.width;
    struct pixel *data = image_transform.data = malloc(width * height * sizeof(struct pixel));

    if (!data) {
        perror("Error: not enough memory for rotate_ccw90");
        exit(1);
    }

    for (uint64_t y = 0; y < width; ++y) {
        for (uint64_t x = 0; x < height; ++x) {
            data[x * width + width - y - 1] = source.data[y*source.width + x];
        }
    }

    return image_transform;
}

struct image rotate_cw90(struct image const source) {
    struct image image_transform;

    uint64_t width = image_transform.width = source.height;
    uint64_t height = image_transform.height = source.width;
    struct pixel *data = image_transform.data = malloc(width * height * sizeof(struct pixel));

    if (!data) {
        perror("Error: not enough memory for rotate_cw90");
        exit(1);
    }

    for (uint64_t y = 0; y < height; ++y) {
        for (uint64_t x = 0; x < width; ++x) {
            data[y * width + x] = source.data[(width - x - 1) * height + y];
        }
    }
    return image_transform;
}

struct image rotate_fliph(struct image const source) {
    struct image image_transform;

    uint64_t width = image_transform.width = source.width;
    uint64_t height = image_transform.height = source.height;
    struct pixel *data = image_transform.data = malloc(width * height * sizeof(struct pixel));

    if (!data) {
        perror("Error: not enough memory for rotate_fliph");
        exit(1);
    }

    for (uint64_t y = 0; y < height; ++y) {
        for (uint64_t x = 0; x < width; ++x) {
            data[y * width + x] = source.data[y * width + (width - x - 1)];
        }
    }
    return image_transform;
}

struct image rotate_flipv(struct image const source) {
    struct image image_transform;

    uint64_t width = image_transform.width = source.width;
    uint64_t height = image_transform.height = source.height;
    struct pixel *data = image_transform.data = malloc(width * height * sizeof(struct pixel));

    if (!data) {
        perror("Error: not enough memory for rotate_flipv");
        exit(1);
    }

    for (uint64_t y = 0; y < height; ++y) {
        for (uint64_t x = 0; x < width; ++x) {
            data[y * width + x] = source.data[(height - y - 1) * width + x];
        }
    }
    return image_transform;
}
