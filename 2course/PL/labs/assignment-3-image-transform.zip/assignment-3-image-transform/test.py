def compare_files(file1_path, file2_path):
    """Сравнивает два файла побитово и выводит информацию об отличиях."""
    count = 0
    try:
        with open('./file_1.txt', "rb") as file1, open('./file_2.txt', "rb") as file2:
            byte1 = file1.read(1)
            byte2 = file2.read(1)
            offset = 0
            while byte1 and byte2:
                if byte1 != byte2:
                    count += 1
                    diff_bits = bin(byte1[0] ^ byte2[0])[2:].zfill(8)
                    print(f"Отличие на смещении {offset}:")
                    print(f"  Файл 1: {byte1[0]:02x} ({bin(byte1[0])[2:].zfill(8)})")
                    print(f"  Файл 2: {byte2[0]:02x} ({bin(byte2[0])[2:].zfill(8)})")
                    print(f"  Различающиеся биты: {diff_bits}")
                    print("\n\nКоличество отличных бит: " + str(count)) 
                byte1 = file1.read(1)
                byte2 = file2.read(1)
                offset += 1

            if len(byte1) != len(byte2):
              print(f"Файлы имеют разный размер!")


    except FileNotFoundError:
        print("Один или оба файла не найдены.")
        # Пример использования
compare_files("file1.bin", "file2.bin")
